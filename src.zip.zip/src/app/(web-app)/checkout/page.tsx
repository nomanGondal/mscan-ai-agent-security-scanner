"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components"
import { Box } from "@radix-ui/themes"
import Link from "next/link"

export default function CheckoutPage() {
  const [selectedPlan, setSelectedPlan] = useState("pro")
  const [billingCycle, setBillingCycle] = useState("monthly")
  const [cardInfo, setCardInfo] = useState({
    name: "",
    email: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  })
  const [processing, setProcessing] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)

  const plans = {
    pro: {
      name: "Pro Plan",
      monthlyPrice: 99,
      yearlyPrice: 990,
      features: [
        "Unlimited scans",
        "Advanced analysis",
        "API access",
        "Priority support",
      ],
    },
    enterprise: {
      name: "Enterprise Plan",
      monthlyPrice: 299,
      yearlyPrice: 2990,
      features: [
        "Everything in Pro",
        "Dedicated support",
        "Custom rules",
        "On-premise option",
      ],
    },
  }

  const currentPlan = plans[selectedPlan as keyof typeof plans]
  const price = billingCycle === "monthly" ? currentPlan.monthlyPrice : currentPlan.yearlyPrice
  const discount = billingCycle === "yearly" ? Math.round(price * 0.1) : 0

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setProcessing(true)

    // Simulate Stripe payment processing
    setTimeout(() => {
      setProcessing(false)
      setOrderComplete(true)
    }, 2000)
  }

  if (orderComplete) {
    return (
      <Box>
        <DashboardHeader type="user" />
        <Box className="w-full px-8 py-8">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white border border-gray-300 rounded-lg p-12 text-center">
              <div className="mb-6">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                  <span className="text-3xl text-green-600">OK</span>
                </div>
              </div>
              <h1 className="text-4xl font-bold text-black mb-4">Payment Successful!</h1>
              <p className="text-gray-600 mb-8">
                Your subscription to the {currentPlan.name} has been activated.
              </p>

              <div className="bg-gray-50 border border-gray-300 rounded p-6 mb-8 text-left">
                <h2 className="text-lg font-bold text-black mb-4">Order Summary</h2>
                <div className="space-y-3 text-gray-700">
                  <div className="flex justify-between">
                    <span>Plan:</span>
                    <span className="font-semibold">{currentPlan.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Billing Cycle:</span>
                    <span className="font-semibold">{billingCycle === "monthly" ? "Monthly" : "Yearly"}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-300 pt-3">
                    <span className="font-bold">Total:</span>
                    <span className="font-bold text-black">${price}/month</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-8">
                <h3 className="text-lg font-bold text-black">You now have access to:</h3>
                <ul className="text-left space-y-2">
                  {currentPlan.features.map((feature, idx) => (
                    <li key={idx} className="text-gray-700">
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-center gap-4">
                <a
                  href="/user/user-dashboard"
                  className="inline-block px-12 py-3 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition"
                >
                  Go to Dashboard
                </a>
                <Link
                  href="/pricing"
                  className="inline-block px-12 py-3 border border-black text-black font-semibold rounded-lg hover:bg-gray-100 transition"
                >
                  Back to Pricing
                </Link>
              </div>
            </div>
          </div>
        </Box>
      </Box>
    )
  }

  return (
    <Box>
      <DashboardHeader type="user" />
      <Box className="w-full px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-black mb-2">Upgrade Your Account</h1>
          <p className="text-gray-600">Complete your payment to unlock unlimited scans and premium features</p>
        </div>

        <div className="grid grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="col-span-1">
            <div className="bg-white border border-gray-300 rounded-lg p-6 sticky top-8">
              <h2 className="text-xl font-bold text-black mb-6">Order Summary</h2>

              {/* Plan Selection */}
              <div className="mb-6 pb-6 border-b border-gray-300">
                <p className="text-sm font-semibold text-gray-700 mb-3">Select Plan</p>
                <div className="space-y-2">
                  {Object.entries(plans).map(([key, plan]) => (
                    <label key={key} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="plan"
                        value={key}
                        checked={selectedPlan === key}
                        onChange={(e) => setSelectedPlan(e.target.value)}
                        className="w-4 h-4"
                      />
                      <span className="text-gray-700">{plan.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Billing Cycle */}
              <div className="mb-6 pb-6 border-b border-gray-300">
                <p className="text-sm font-semibold text-gray-700 mb-3">Billing Cycle</p>
                <div className="space-y-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="cycle"
                      value="monthly"
                      checked={billingCycle === "monthly"}
                      onChange={(e) => setBillingCycle(e.target.value)}
                      className="w-4 h-4"
                    />
                    <span className="text-gray-700">Monthly</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="cycle"
                      value="yearly"
                      checked={billingCycle === "yearly"}
                      onChange={(e) => setBillingCycle(e.target.value)}
                      className="w-4 h-4"
                    />
                    <span className="text-gray-700">Yearly (Save 10%)</span>
                  </label>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3">
                <div className="flex justify-between text-gray-700">
                  <span>Subtotal:</span>
                  <span>${price}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount:</span>
                    <span>-${discount}</span>
                  </div>
                )}
                <div className="border-t border-gray-300 pt-3 flex justify-between font-bold text-black">
                  <span>Total:</span>
                  <span>${price - discount}</span>
                </div>
                <p className="text-xs text-gray-600 text-center">Billed {billingCycle === "monthly" ? "monthly" : "yearly"}</p>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="col-span-2">
            <div className="bg-white border border-gray-300 rounded-lg p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Billing Information */}
                <div>
                  <h3 className="text-lg font-bold text-black mb-4">Billing Information</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-black mb-2">Full Name</label>
                      <input
                        type="text"
                        required
                        value={cardInfo.name}
                        onChange={(e) => setCardInfo({ ...cardInfo, name: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black transition"
                        placeholder="John Doe"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-black mb-2">Email Address</label>
                      <input
                        type="email"
                        required
                        value={cardInfo.email}
                        onChange={(e) => setCardInfo({ ...cardInfo, email: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black transition"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Information */}
                <div>
                  <h3 className="text-lg font-bold text-black mb-4">Payment Information</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-black mb-2">Card Number</label>
                      <input
                        type="text"
                        required
                        placeholder="4242 4242 4242 4242"
                        value={cardInfo.cardNumber}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, cardNumber: e.target.value.replace(/\s/g, "").slice(0, 16) })
                        }
                        maxLength={19}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black transition font-mono"
                      />
                      <p className="text-xs text-gray-600 mt-2">Test card: 4242 4242 4242 4242</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-black mb-2">Expiry Date</label>
                        <input
                          type="text"
                          required
                          placeholder="MM/YY"
                          value={cardInfo.expiryDate}
                          onChange={(e) => setCardInfo({ ...cardInfo, expiryDate: e.target.value.slice(0, 5) })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black transition"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-black mb-2">CVV</label>
                        <input
                          type="text"
                          required
                          placeholder="123"
                          value={cardInfo.cvv}
                          onChange={(e) => setCardInfo({ ...cardInfo, cvv: e.target.value.slice(0, 4) })}
                          maxLength={4}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black transition"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Terms */}
                <div className="bg-gray-50 border border-gray-300 rounded p-4">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input type="checkbox" required className="w-4 h-4 mt-1" />
                    <span className="text-sm text-gray-700">
                      I agree to the{" "}
                      <a href="#" className="text-black font-semibold hover:underline">
                        Terms of Service
                      </a>{" "}
                      and{" "}
                      <a href="#" className="text-black font-semibold hover:underline">
                        Privacy Policy
                      </a>
                    </span>
                  </label>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={processing}
                  className={`w-full py-4 font-semibold rounded-lg transition text-lg ${
                    processing
                      ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                      : "bg-black text-white hover:bg-gray-800"
                  }`}
                >
                  {processing ? "Processing..." : `Pay $${price - discount}`}
                </button>

                {/* Security Note */}
                <p className="text-xs text-gray-600 text-center">
                  🔒 Your payment information is processed securely by Stripe.
                </p>
              </form>
            </div>
          </div>
        </div>
      </Box>
    </Box>
  )
}
