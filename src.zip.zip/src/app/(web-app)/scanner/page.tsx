"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components"
import { Box } from "@radix-ui/themes"
import ScannerService from "@/services/scanner"

const DEMO_CODE = `# Vulnerable Python Code Example
import os
import hashlib

DB_PASSWORD = "admin123"

def authenticate(user_input):
    query = f"SELECT * FROM users WHERE id = {user_input}"
    db.execute(query)

def execute_command(user_provided_name):
    os.system(f"echo {user_provided_name}")

def get_file(request):
    path = f"/files/{request.args.get('filename')}"
    return open(path, "r")

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()`

export default function ScannerPage() {
  const [activeTab, setActiveTab] = useState<"upload" | "demo">("upload")
  const [scanning, setScanning] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [progress, setProgress] = useState(0)
  const [scanResults, setScanResults] = useState<any>(null)
  const [demoResults, setDemoResults] = useState<any>(null)
  const [isDemoScanning, setIsDemoScanning] = useState(false)

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFile(e.target.files[0])
    }
  }

  const handleStartScan = async () => {
    if (!selectedFile) return

    setScanning(true)
    setProgress(0)
    setScanResults(null)

    // Simulate scanning progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval)
          return prev
        }
        return prev + Math.random() * 25
      })
    }, 800)

    // Simulate scan completion after 5 seconds
    setTimeout(() => {
      clearInterval(interval)
      setProgress(100)
      setScanning(false)
      setScanResults({
        fileName: selectedFile.name,
        totalIssues: 12,
        critical: 2,
        high: 5,
        medium: 3,
        low: 2,
        duration: 3.5,
      })
    }, 5000)
  }

  const startDemoScan = async () => {
    setIsDemoScanning(true)
    setProgress(0)
    setDemoResults(null)

    try {
      const result = await ScannerService.scanModel({
        filename: "demo_vulnerable.py",
        code: DEMO_CODE,
      })

      if (result) {
        setDemoResults({
          fileName: "demo_vulnerable.py",
          duration: result.scan_time ?? 0,
          issues: result.vulnerabilities.map((issue) => ({
            severity: issue.severity,
            type: issue.title,
            description: issue.description,
            line: issue.line,
            column: issue.column,
          })),
          severitySummary: {
            critical: result.summary.critical_count,
            high: result.summary.high_count,
            medium: result.summary.medium_count,
            low: result.summary.low_count,
          },
        })
        setProgress(100)
      }
    } catch (error) {
      console.error("Demo scan failed:", error)
    } finally {
      setIsDemoScanning(false)
    }
  }

  return (
    <Box>
      <DashboardHeader type="user" />
      <Box className="w-full px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-black mb-2">Code Scanner</h1>
          <p className="text-gray-600">
            Upload your code for comprehensive security analysis with MCP, Pyre, and Pysa
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-8 mb-8 border-b border-gray-300 max-w-3xl mx-auto">
          <button
            onClick={() => setActiveTab("upload")}
            className={`px-4 py-4 font-medium transition border-b-2 ${
              activeTab === "upload"
                ? "text-black border-b-black"
                : "text-gray-600 border-b-transparent hover:text-black"
            }`}
          >
            Upload File
          </button>
          <button
            onClick={() => setActiveTab("demo")}
            className={`px-4 py-4 font-medium transition border-b-2 ${
              activeTab === "demo"
                ? "text-black border-b-black"
                : "text-gray-600 border-b-transparent hover:text-black"
            }`}
          >
            Demo Test
          </button>
        </div>

        <div className="max-w-3xl mx-auto">
          {/* Upload Tab */}
          {activeTab === "upload" && (
            <>
              {!scanResults && (
                <>
                  <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-black transition">
            <div className="mb-4">
              <div className="w-16 h-16 mx-auto bg-gray-100 rounded-lg flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-600">F</span>
              </div>
            </div>

            <label className="cursor-pointer">
              <span className="text-lg font-semibold text-black">Drop your files here</span>
              <input
                type="file"
                className="hidden"
                accept=".zip,.py,.txt"
                onChange={handleFileSelect}
              />
            </label>
            <p className="text-sm text-gray-600 mt-2">or click to select</p>
            <p className="text-xs text-gray-500 mt-2">ZIP files, Python files, or projects supported</p>

            {selectedFile && (
              <div className="mt-6 pt-6 border-t border-gray-300">
                <div className="flex items-center justify-between bg-gray-50 rounded p-4">
                  <div className="text-left">
                    <p className="text-sm font-semibold text-black">{selectedFile.name}</p>
                    <p className="text-xs text-gray-600">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="text-gray-500 hover:text-black font-bold text-lg"
                  >
                    X
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Scan Button */}
          <div className="mt-8 text-center">
            <button
              onClick={handleStartScan}
              disabled={!selectedFile || scanning}
              className={`px-12 py-4 font-semibold rounded-lg transition ${
                !selectedFile || scanning
                  ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                  : "bg-black text-white hover:bg-gray-800"
              }`}
            >
              {scanning ? "Scanning..." : "Start Scan"}
            </button>
          </div>
                </>
              )}

              {/* Scanning Progress */}
              {scanning && (
                <div className="bg-white border border-gray-300 rounded-lg p-8">
              <div className="space-y-6">
                {/* Professional Loading Animation */}
                <div className="flex flex-col items-center justify-center py-8">
                  <div className="relative w-16 h-16 mb-4">
                    <div className="absolute inset-0 border-4 border-gray-200 rounded-full"></div>
                    <div
                      className="absolute inset-0 border-4 border-transparent border-t-black border-r-black rounded-full animate-spin"
                      style={{ animationDuration: "1.5s" }}
                    ></div>
                  </div>
                  <p className="text-lg font-semibold text-black">Analyzing your code...</p>
                  <p className="text-sm text-gray-600 mt-2">{Math.round(progress)}% Complete</p>
                </div>

                {/* Progress stages */}
                <div className="space-y-3">
                  {[
                    { stage: "MCP AST Analysis", threshold: 33 },
                    { stage: "Pyre Type Checking", threshold: 66 },
                    { stage: "Pysa Taint Analysis", threshold: 100 },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                          progress >= item.threshold
                            ? "border-black bg-black"
                            : "border-gray-300 bg-white"
                        }`}
                      >
                        {progress >= item.threshold && (
                          <span className="text-white text-xs font-bold">+</span>
                        )}
                      </div>
                      <span
                        className={`text-sm transition ${
                          progress >= item.threshold ? "text-black font-medium" : "text-gray-400"
                        }`}
                      >
                        {item.stage}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Progress bar */}
                <div className="mt-6">
                  <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-black h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          )}

              {/* Scan Results */}
              {scanResults && !scanning && (
                <div className="bg-white border border-gray-300 rounded-lg p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-green-600 font-bold">OK</span>
                    </div>
                    <h2 className="text-2xl font-bold text-black">Scan Complete!</h2>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-gray-600">
                      Scanned: <span className="font-medium text-black">{scanResults.fileName}</span>
                    </p>
                    <p className="text-sm text-gray-600">
                      Duration: <span className="font-medium text-black">{scanResults.duration}s</span>
                    </p>
                  </div>

                  <div className="grid grid-cols-4 gap-4 mb-6">
                    <div className="bg-gray-50 rounded p-4">
                      <p className="text-sm text-gray-600 mb-1">Total Issues</p>
                      <p className="text-2xl font-bold text-black">{scanResults.totalIssues}</p>
                    </div>
                    <div className="bg-red-50 rounded p-4 border-l-4 border-red-600">
                      <p className="text-sm text-gray-600 mb-1">Critical</p>
                      <p className="text-2xl font-bold text-red-600">{scanResults.critical}</p>
                    </div>
                    <div className="bg-orange-50 rounded p-4 border-l-4 border-orange-600">
                      <p className="text-sm text-gray-600 mb-1">High</p>
                      <p className="text-2xl font-bold text-orange-600">{scanResults.high}</p>
                    </div>
                    <div className="bg-yellow-50 rounded p-4 border-l-4 border-yellow-600">
                      <p className="text-sm text-gray-600 mb-1">Medium/Low</p>
                      <p className="text-2xl font-bold text-yellow-600">{scanResults.medium + scanResults.low}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setProgress(0)
                      setSelectedFile(null)
                      setScanResults(null)
                    }}
                    className="px-8 py-3 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition"
                  >
                    Scan Another Project
                  </button>
                </div>
              )}
            </>
          )}

          {/* Demo Tab */}
          {activeTab === "demo" && (
            <>
              {!demoResults && (
                <>
                  <div className="bg-white border border-gray-300 rounded-lg p-6 mb-6">
                    <h2 className="text-lg font-bold text-black mb-4">Vulnerable Code Example</h2>
                    <div className="bg-gray-900 rounded p-4 overflow-x-auto mb-4">
                      <pre className="text-gray-300 text-sm font-mono whitespace-pre-wrap break-words">
                        {DEMO_CODE}
                      </pre>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">
                      This demo code contains several intentional security vulnerabilities. Click "Run Demo Test" to see how the
                      scanner identifies them.
                    </p>
                    <button
                      onClick={startDemoScan}
                      disabled={isDemoScanning}
                      className={`px-12 py-4 font-semibold rounded-lg transition ${
                        isDemoScanning
                          ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                          : "bg-black text-white hover:bg-gray-800"
                      }`}
                    >
                      {isDemoScanning ? "Running Demo Test..." : "Run Demo Test"}
                    </button>
                  </div>

                  {isDemoScanning && (
                    <div className="bg-white border border-gray-300 rounded-lg p-8">
                      <div className="space-y-6">
                        {/* Professional Loading Animation */}
                        <div className="flex flex-col items-center justify-center py-8">
                          <div className="relative w-16 h-16 mb-4">
                            <div className="absolute inset-0 border-4 border-gray-200 rounded-full"></div>
                            <div
                              className="absolute inset-0 border-4 border-transparent border-t-black border-r-black rounded-full animate-spin"
                              style={{ animationDuration: "1.5s" }}
                            ></div>
                          </div>
                          <p className="text-lg font-semibold text-black">Running security analysis...</p>
                          <p className="text-sm text-gray-600 mt-2">Processing vulnerable code</p>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Demo Results */}
              {demoResults && !isDemoScanning && (
                <div className="bg-white border border-gray-300 rounded-lg p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-green-600 font-bold">OK</span>
                    </div>
                    <h2 className="text-2xl font-bold text-black">Analysis Complete!</h2>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-gray-600">
                      File: <span className="font-medium text-black">{demoResults.fileName}</span>
                    </p>
                    <p className="text-sm text-gray-600">
                      Duration: <span className="font-medium text-black">{(demoResults.duration / 1000).toFixed(2)}s</span>
                    </p>
                  </div>

                  <div className="grid grid-cols-4 gap-4 mb-6">
                    <div className="bg-gray-50 rounded p-4">
                      <p className="text-sm text-gray-600 mb-1">Total Issues</p>
                      <p className="text-2xl font-bold text-black">{demoResults.issues?.length || 0}</p>
                    </div>
                    <div className="bg-red-50 rounded p-4 border-l-4 border-red-600">
                      <p className="text-sm text-gray-600 mb-1">Critical</p>
                      <p className="text-2xl font-bold text-red-600">{demoResults.severitySummary?.critical || 0}</p>
                    </div>
                    <div className="bg-orange-50 rounded p-4 border-l-4 border-orange-600">
                      <p className="text-sm text-gray-600 mb-1">High</p>
                      <p className="text-2xl font-bold text-orange-600">{demoResults.severitySummary?.high || 0}</p>
                    </div>
                    <div className="bg-yellow-50 rounded p-4 border-l-4 border-yellow-600">
                      <p className="text-sm text-gray-600 mb-1">Medium/Low</p>
                      <p className="text-2xl font-bold text-yellow-600">
                        {(demoResults.severitySummary?.medium || 0) + (demoResults.severitySummary?.low || 0)}
                      </p>
                    </div>
                  </div>

                  {/* Issues Details */}
                  {demoResults.issues && demoResults.issues.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-bold text-black mb-4">Detected Issues</h3>
                      <div className="space-y-4 max-h-96 overflow-y-auto">
                        {demoResults.issues.map((issue, idx) => (
                          <div key={idx} className="border border-gray-200 rounded p-4">
                            <div className="flex items-start gap-3">
                              <div
                                className={`px-2 py-1 rounded text-xs font-semibold ${
                                  issue.severity === "critical"
                                    ? "bg-red-100 text-red-700"
                                    : issue.severity === "high"
                                    ? "bg-orange-100 text-orange-700"
                                    : issue.severity === "medium"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-blue-100 text-blue-700"
                                }`}
                              >
                                {issue.severity.toUpperCase()}
                              </div>
                              <div className="flex-1">
                                <p className="font-semibold text-black">{issue.type}</p>
                                <p className="text-sm text-gray-600 mt-1">{issue.description}</p>
                                <p className="text-xs text-gray-500 mt-2">
                                  Line {issue.line}, Column {issue.column}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      setDemoResults(null)
                    }}
                    className="px-8 py-3 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition"
                  >
                    Run Another Demo
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Info Section */}
        <div className="mt-16 grid grid-cols-3 gap-8">
          <div className="bg-white border border-gray-300 rounded-lg p-6">
            <h3 className="text-lg font-bold text-black mb-3">MCP AST Analysis</h3>
            <p className="text-sm text-gray-600">Deep inspection of MCP tool definitions and server implementation for vulnerability patterns</p>
          </div>
          <div className="bg-white border border-gray-300 rounded-lg p-6">
            <h3 className="text-lg font-bold text-black mb-3">Pyre Type Checking</h3>
            <p className="text-sm text-gray-600">Static type analysis to catch type-related vulnerabilities and unsafe code patterns</p>
          </div>
          <div className="bg-white border border-gray-300 rounded-lg p-6">
            <h3 className="text-lg font-bold text-black mb-3">Pysa Taint Analysis</h3>
            <p className="text-sm text-gray-600">Advanced taint tracking to identify data flow vulnerabilities and security risks</p>
          </div>
        </div>
      </Box>
    </Box>
  )
}
