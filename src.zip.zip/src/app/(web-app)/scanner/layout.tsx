import React from "react"

const ScannerLayout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>
}

export default ScannerLayout
