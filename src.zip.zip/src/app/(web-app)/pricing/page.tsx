"use client"

import Link from "next/link"
import { DashboardHeader } from "@/components"
import { Box } from "@radix-ui/themes"

const PLANS = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "For small projects and quick checks.",
    features: ["3 scans per month", "Core analysis tools", "Scan history"],
    cta: "Current Plan",
    highlight: false,
    href: null,
  },
  {
    name: "Pro",
    price: "$99",
    period: "per month",
    description: "For teams that scan regularly.",
    features: ["Unlimited scans", "Detailed reports", "Usage analytics", "Priority support"],
    cta: "Go to Checkout",
    highlight: true,
    href: "/checkout",
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "contact sales",
    description: "For organizations that need custom controls.",
    features: ["Dedicated support", "Custom rules", "Team workflows", "SLA options"],
    cta: "Contact Sales",
    highlight: false,
    href: "mailto:sales@example.com",
  },
]

export default function PricingPage() {
  return (
    <Box>
      <DashboardHeader type="user" />
      <Box className="w-full px-8 py-8">
        <div className="text-center mb-14 max-w-3xl mx-auto">
          <h1 className="text-5xl font-bold text-black mb-4">Pricing</h1>
          <p className="text-lg text-gray-600">
            Choose a plan that fits your scan volume and support needs.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`border rounded-lg p-8 bg-white relative ${
                plan.highlight ? "border-black shadow-lg" : "border-gray-300"
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-black text-white px-4 py-1 rounded-full text-xs font-semibold">
                    Recommended
                  </span>
                </div>
              )}

              <h2 className="text-3xl font-bold text-black mb-2">{plan.name}</h2>
              <div className="mb-6">
                <span className="text-4xl font-bold text-black">{plan.price}</span>
                <span className="ml-2 text-sm text-gray-600">{plan.period}</span>
              </div>

              <p className="text-gray-600 mb-6">{plan.description}</p>

              <ul className="space-y-3 mb-8 text-gray-700">
                {plan.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>

              {plan.href ? (
                <Link
                  href={plan.href}
                  className={`block w-full text-center py-3 rounded-lg font-semibold transition ${
                    plan.highlight
                      ? "bg-black text-white hover:bg-gray-800"
                      : "border border-black text-black hover:bg-gray-100"
                  }`}
                >
                  {plan.cta}
                </Link>
              ) : (
                <button
                  disabled
                  className="w-full py-3 rounded-lg font-semibold bg-gray-200 text-gray-600 cursor-not-allowed"
                >
                  {plan.cta}
                </button>
              )}
            </div>
          ))}
        </div>

        <div className="max-w-3xl mx-auto mt-16 bg-white border border-gray-300 rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold text-black mb-3">Need a custom setup?</h2>
          <p className="text-gray-600 mb-6">
            Enterprise plans can be tailored to your workflow, compliance needs, and team size.
          </p>
          <Link
            href="/checkout"
            className="inline-block px-10 py-3 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition"
          >
            Continue to Checkout
          </Link>
        </div>
      </Box>
    </Box>
  )
}