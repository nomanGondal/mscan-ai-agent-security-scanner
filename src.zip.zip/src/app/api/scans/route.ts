import { connectDB } from "@/lib/db"
import { ScanModel, UserModel, AccountModel } from "@/entities"
import { getServerSession } from "next-auth/next"
import { NextRequest, NextResponse } from "next/server"
import { authOptions } from "../auth/[...nextauth]/options"
import { ACCOUNT_TYPES } from "@/constants"

export async function GET() {
  try {
    await connectDB()

    const session = await getServerSession(authOptions)

    if (!session?.user?._id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await UserModel.findById(session.user._id).exec()

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const scans = await ScanModel.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(50)
      .exec()

    return NextResponse.json({
      success: true,
      data: scans,
    })
  } catch (error) {
    console.error("Error fetching scans:", error)
    return NextResponse.json({ error: "Failed to fetch scans" }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectDB()

    const session = await getServerSession(authOptions)

    if (!session?.user?._id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()

    const user = await UserModel.findById(session.user._id).exec()

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    let account = await AccountModel.findOne({ user: user._id }).exec()

    if (!account) {
      account = await AccountModel.create({
        user: user._id,
        plan: ACCOUNT_TYPES.FREE,
        reportsUsed: 0,
        reportsLimit: 3,
        isTrialActive: true,
      })
    }

    const scan = await ScanModel.create({
      ...body,
      user: user._id,
      account: account._id,
      status: body.status || "analyzing",
      completedAt: body.status === "completed" ? body.completedAt || new Date() : body.completedAt,
    })

    if (body.status === "completed") {
      account.reportsUsed = (account.reportsUsed || 0) + 1
      await account.save()
    }

    return NextResponse.json({
      success: true,
      data: scan,
    })
  } catch (error) {
    console.error("Error creating scan:", error)
    return NextResponse.json({ error: "Failed to create scan" }, { status: 500 })
  }
}
