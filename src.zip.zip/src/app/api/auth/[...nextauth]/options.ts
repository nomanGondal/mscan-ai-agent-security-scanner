import { UserModel } from "@/entities/user.model"
import { connect_db } from "@/settings"
import { NextAuthOptions } from "next-auth"
import bcrypt from "bcrypt"
import CredentialsProvider from "next-auth/providers/credentials"
import { ignoreListAnonymousStackFramesIfSandwiched } from "next/dist/next-devtools/server/shared"
import { MAX_AGE } from "@/constants"

const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      id: "credentials",
      name: "credentials",
      credentials: {
        identifier: { label: "Email or Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials) return null
        await connect_db()
        const user = await UserModel.findOne({
          $or: [
            { email: credentials.identifier },
            { username: credentials.identifier },
          ],
        })
        if (!user) return null
        if (!user.isUserVerified) return null
        const isPasswordMatched = await bcrypt.compare(
          credentials.password,
          user.password
        )
        if (!isPasswordMatched) return null
        return {
          id: user._id.toString(),
          username: user?.username,
          fullName: user?.fullName,
          isUserVerified: user?.isUserVerified,
          isActive: user?.isActive,
          role: user?.role,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user?.id
        token.username = user?.username
        token.isUserVerified = user?.isUserVerified
        token.fullName = user?.fullName
        token.isActive = user?.isActive
        token.role = user?.role
      }
      return token
    },
    async session({ session, token }) {
      session.user = {
        _id: token.id as string,
        username: token.username as string,
        isUserVerified: token.isUserVerified as boolean,
        fullName: token.fullName as string,
        isActive: token.isActive as boolean,
        role: token.role as string,
      }
      return session
    },
  },

  session: { strategy: "jwt", maxAge: MAX_AGE },
  pages: { signIn: "/signin" },
  secret: process.env.NEXTAUTH_SECRET,
}

export { authOptions }
