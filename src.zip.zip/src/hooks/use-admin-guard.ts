import { UNAUTHORIZED, ADMIN_DASHBOARD } from "@/constants"
import { useNavigation } from "@/utiils"
import { useSession } from "next-auth/react"
import { useEffect, useRef } from "react"

const useAdminGuard = () => {
  const { data: session, status } = useSession()
  const { navigateTo } = useNavigation()
  const checked = useRef(false)

  useEffect(() => {
    if (status === "loading" || checked.current) return
    checked.current = true

    const path = window.location.pathname
    if (path === ADMIN_DASHBOARD) return
    if (!session || session.user.role !== "admin") {
      navigateTo(UNAUTHORIZED)
    }
  }, [status, session])
}

export { useAdminGuard }
