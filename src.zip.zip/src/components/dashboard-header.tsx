"use client"

import { useSession, signOut } from "next-auth/react"
import { useState } from "react"
import { Box } from "@radix-ui/themes"
import {
  USER_HEADER_LINKS,
  ADMIN_HEADER_LINKS,
  USER_DROPDOWN,
  ADMIN_DROPDOWN,
  AUTH,
} from "@/constants"
import Link from "next/link"

interface DashboardHeaderProps {
  type: "user" | "admin"
}

const DashboardHeader = ({ type }: DashboardHeaderProps) => {
  const { data: session } = useSession()
  const [dropdownOpen, setDropdownOpen] = useState(false)

  const links = type === "admin" ? ADMIN_HEADER_LINKS : USER_HEADER_LINKS
  const dropdownOptions = type === "admin" ? ADMIN_DROPDOWN : USER_DROPDOWN

  const avatarLetter = session?.user?.username?.[0]?.toUpperCase() || "U"

  const handleSignOut = async () => {
    await signOut({ callbackUrl: AUTH })
  }

  return (
    <Box className="w-full flex justify-between items-center px-8 py-6 bg-white border-b border-gray-200">
      <Box className="text-2xl font-bold text-black">
        MCP Taint Analyzer
      </Box>
      <Box className="flex gap-12">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="text-gray-700 font-medium hover:text-black transition"
          >
            {link.label}
          </Link>
        ))}
      </Box>
      <Box className="relative">
        <button
          onClick={() => setDropdownOpen((prev) => !prev)}
          className="w-10 h-10 rounded-full flex items-center justify-center bg-black text-white font-semibold hover:bg-gray-800 transition"
        >
          {avatarLetter}
        </button>

        {dropdownOpen && (
          <Box className="absolute right-0 mt-2 w-56 bg-white shadow-lg rounded-lg border border-gray-300 z-50">
            <Box className="px-4 py-3 border-b border-gray-200">
              <p className="text-sm font-semibold text-black">
                {session?.user?.name || "User"}
              </p>
              <p className="text-xs text-gray-600">
                {session?.user?.email}
              </p>
            </Box>
            {dropdownOptions.map((option) => (
              <Link
                key={option.href}
                href={option.href}
                className="block px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-black transition border-b border-gray-100 last:border-b-0"
                onClick={() => setDropdownOpen(false)}
              >
                {option.label}
              </Link>
            ))}
            <button
              onClick={handleSignOut}
              className="w-full text-left px-4 py-3 text-gray-700 hover:bg-red-50 hover:text-red-600 transition font-medium"
            >
              Sign Out
            </button>
          </Box>
        )}
      </Box>
    </Box>
  )
}

export { DashboardHeader }
