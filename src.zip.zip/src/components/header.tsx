"use client"

import { Box } from "@radix-ui/themes"
import { Label } from "./ui/label"
import { Montserrat } from "next/font/google"
import {
  Breadcrumb,
  BreadcrumbEllipsis,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "./ui/breadcrumb"
import Link from "next/link"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { Button } from "./ui/button"
import { cn, underlineAnimation } from "@/utiils"
import { RightArrow } from "./icons/right-arrow"
import { AUTH, REGISTRATION } from "@/constants"

const bokorFont = Montserrat({
  subsets: ["latin"],
  weight: "400",
})

const Header = () => {
  return (
    <Box
      className={cn(
        bokorFont.className,
        "w-4/5 mx-auto border border-gray-200 h-16 flex items-center px-4 text-black rounded-full shadow-md bg-white"
      )}
    >
      <Box className="flex-1 flex items-center">
        <Label className="font-bold text-lg">MVSCAN.</Label>
      </Box>

      <Box className="flex-1 flex justify-center">
        <Breadcrumb>
          <BreadcrumbList className="text-black">
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/" className="hover:!text-black/90">
                  Home
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-1 focus:outline-none cursor-pointer">
                  <BreadcrumbEllipsis className="size-4" />
                  <span className="sr-only">Toggle menu</span>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="start"
                  className="bg-white shadow-lg border-1 border-gray-200 text-black"
                >
                  <DropdownMenuItem className="cursor-pointer hover:bg-gray-50">
                    Documentation
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer hover:bg-gray-50">
                    Github
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/about" className="hover:!text-black/90">
                  About
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/contact" className="hover:!text-black/90">
                  Contact
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </Box>
      <Box className="flex-1 flex justify-end gap-3">
        <Button className={underlineAnimation}>
          <Link href={AUTH}>Login</Link>
        </Button>
        <Button
          asChild
          className="p-4 bg-black text-white rounded-full cursor-pointer"
        >
          <Box className="flex justify-center items-center ">
            <Link href={REGISTRATION}>
              <Label className="font-thin cursor-pointer mb-1">Sign up</Label>
            </Link>
            <RightArrow />
          </Box>
        </Button>
      </Box>
    </Box>
  )
}

export { Header }
