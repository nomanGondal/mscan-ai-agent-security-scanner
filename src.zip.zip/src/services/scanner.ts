import { API_ENDPOINTS } from "@/actions";
import axios, { AxiosError } from "axios";

export interface ScanRequest {
  filename: string;
  code: string;
}

export interface ScanResult {
  project_id: string;
  status: string;
  vulnerabilities: Vulnerability[];
  summary: {
    total_issues: number;
    critical_count: number;
    high_count: number;
    medium_count: number;
    low_count: number;
  };
  analysisBreakdown?: {
    ast: number;
    pyre: number;
    pysa: number;
  };
  files_analyzed: number;
  scan_time?: number;
  timestamp?: string;
}

export interface Vulnerability {
  id?: string;
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  description: string;
  analysisStage?: "mcp_ast" | "pyre_typing" | "pysa_taint" | "unknown";
  file?: string;
  line?: number;
  column?: number;
  code_snippet?: string;
  recommendation?: string;
  cwe?: string;
  owasp?: string;
}

interface ApiResponse {
  success?: boolean;
  message?: string;
  data?: ScanResult;
  [key: string]: any;
}

interface BackendScanIssue {
  severity?: "critical" | "high" | "medium" | "low" | string;
  type?: string;
  rule?: string;
  stage?: "mcp_ast" | "pyre_typing" | "pysa_taint" | "unknown" | string;
  description?: string;
  file?: string;
  line?: number;
  column?: number;
  code?: string;
  fix?: string;
  recommendation?: string;
  cwe?: string;
  owasp?: string;
}

interface BackendScanResponse {
  project_id?: string;
  issues_count?: number;
  issues_details?: BackendScanIssue[];
  summary?: {
    total?: number;
    high?: number;
    medium?: number;
    low?: number;
    pyre_issues?: number;
    pysa_issues?: number;
    mcp_issues?: number;
  };
  debug?: {
    duration_seconds?: number;
  };
}

interface PersistedScanIssue {
  severity: "critical" | "high" | "medium" | "low";
  type: string;
  description: string;
  stage: "mcp_ast" | "pyre_typing" | "pysa_taint" | "unknown";
  line: number;
  column: number;
  file?: string;
  code?: string;
}

const normalizeSeverity = (
  severity?: string,
): "critical" | "high" | "medium" | "low" => {
  const normalizedSeverity = severity?.toLowerCase();
  if (
    normalizedSeverity === "critical" ||
    normalizedSeverity === "high" ||
    normalizedSeverity === "medium" ||
    normalizedSeverity === "low"
  ) {
    return normalizedSeverity;
  }
  return "low";
};

const inferAnalysisStage = (
  issue: BackendScanIssue,
): "mcp_ast" | "pyre_typing" | "pysa_taint" | "unknown" => {
  const explicitStage = issue.stage?.toLowerCase();
  if (
    explicitStage === "mcp_ast" ||
    explicitStage === "pyre_typing" ||
    explicitStage === "pysa_taint" ||
    explicitStage === "unknown"
  ) {
    return explicitStage;
  }

  const searchText = `${issue.type ?? ""} ${issue.rule ?? ""} ${issue.description ?? ""}`.toLowerCase();

  if (
    searchText.includes("undefined import") ||
    searchText.includes("undefined or invalid type") ||
    searchText.includes("call error") ||
    searchText.includes("invalid decoration") ||
    searchText.includes("unbound name") ||
    searchText.includes("annotation") ||
    searchText.includes("type")
  ) {
    return "pyre_typing";
  }

  if (
    searchText.includes("ssrf") ||
    searchText.includes("shell injection") ||
    searchText.includes("command injection") ||
    searchText.includes("file system access") ||
    searchText.includes("deserializ") ||
    searchText.includes("path traversal") ||
    searchText.includes("prompt injection") ||
    searchText.includes("taint") ||
    searchText.includes("sql injection")
  ) {
    return "pysa_taint";
  }

  return "mcp_ast";
};

const toFrontendScanResult = (data: BackendScanResponse): ScanResult => {
  const vulnerabilities = (data.issues_details ?? []).map((issue) => ({
    severity: normalizeSeverity(issue.severity),
    title: issue.type || issue.rule || "Finding",
    description: issue.description || issue.rule || "",
    analysisStage: inferAnalysisStage(issue),
    file: issue.file,
    line: issue.line,
    column: issue.column,
    code_snippet: issue.code || issue.fix,
    recommendation: issue.recommendation || issue.fix,
    cwe: issue.cwe,
    owasp: issue.owasp,
  }));

  const criticalCount = vulnerabilities.filter(
    (issue) => issue.severity === "critical",
  ).length;

  return {
    project_id: data.project_id || "demo-project",
    status: "completed",
    vulnerabilities,
    summary: {
      total_issues: data.summary?.total ?? data.issues_count ?? vulnerabilities.length,
      critical_count: criticalCount,
      high_count: data.summary?.high ?? 0,
      medium_count: data.summary?.medium ?? 0,
      low_count: data.summary?.low ?? 0,
    },
    analysisBreakdown: {
      ast: data.summary?.mcp_issues ?? 0,
      pyre: data.summary?.pyre_issues ?? 0,
      pysa: data.summary?.pysa_issues ?? 0,
    },
    files_analyzed: vulnerabilities.length ? 1 : 0,
    scan_time: data.debug?.duration_seconds,
    timestamp: new Date().toISOString(),
  };
};

const persistCompletedScan = async (
  payload: {
    fileName: string;
    fileSize: number;
    fileContent?: string;
    result: ScanResult;
  },
) => {
  const issues: PersistedScanIssue[] = payload.result.vulnerabilities.map(
    (issue) => ({
      severity: issue.severity,
      type: issue.title,
      description: issue.description,
      stage: issue.analysisStage ?? "unknown",
      line: issue.line ?? 0,
      column: issue.column ?? 0,
      file: issue.file,
      code: issue.code_snippet,
    }),
  );

  await fetch("/api/scans", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      fileName: payload.fileName,
      fileSize: payload.fileSize,
      fileContent: payload.fileContent,
      status: "completed",
      completedAt: new Date().toISOString(),
      duration: Math.round((payload.result.scan_time ?? 0) * 1000),
      issues,
      severitySummary: {
        critical: payload.result.summary.critical_count,
        high: payload.result.summary.high_count,
        medium: payload.result.summary.medium_count,
        low: payload.result.summary.low_count,
      },
      analysisTools: {
        mcp_ast: true,
        pyre_typing: true,
        pysa_taint: true,
      },
    }),
  });
};

const ScannerService = {
  async scanModel(
    request: ScanRequest,
    signal?: AbortSignal,
  ): Promise<ScanResult | null> {
    try {
      const response = await axios.post<ScanResult>(
        API_ENDPOINTS.scanner_scan_model,
        request,
        { signal },
      );
      const result = toFrontendScanResult(
        response.data as unknown as BackendScanResponse,
      );

      await persistCompletedScan({
        fileName: request.filename,
        fileSize: request.code.length,
        fileContent: request.code,
        result,
      });

      return result;
    } catch (error: unknown) {
      const axiosError = error as AxiosError<ApiResponse>;
      if (axiosError.code === "ERR_CANCELLED") {
        throw new Error("Request cancelled");
      }
      throw new Error(
        axiosError.response?.data?.message ||
          axiosError.message ||
          "Scan failed",
      );
    }
  },

  async scanZip(file: File, signal?: AbortSignal): Promise<ScanResult | null> {
    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await axios.post<BackendScanResponse>(
        API_ENDPOINTS.scanner_scan_zip,
        formData,
        {
          signal,
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      );
      const result = toFrontendScanResult(response.data);

      await persistCompletedScan({
        fileName: file.name,
        fileSize: file.size,
        result,
      });

      return result;
    } catch (error: unknown) {
      const axiosError = error as AxiosError<ApiResponse>;
      if (axiosError.code === "ERR_CANCELLED") {
        throw new Error("Request cancelled");
      }
      throw new Error(
        axiosError.response?.data?.message ||
          axiosError.response?.data?.detail ||
          axiosError.message ||
          "ZIP scan failed",
      );
    }
  },

  async scanGithub(
    url: string,
    githubToken?: string,
    signal?: AbortSignal,
  ): Promise<ScanResult | null> {
    try {
      const response = await axios.post<BackendScanResponse>(
        API_ENDPOINTS.scanner_scan_github,
        { url, github_token: githubToken },
        { signal },
      );
      const result = toFrontendScanResult(response.data);

      await persistCompletedScan({
        fileName: url,
        fileSize: 0,
        result,
      });

      return result;
    } catch (error: unknown) {
      const axiosError = error as AxiosError<ApiResponse>;
      if (axiosError.code === "ERR_CANCELLED") {
        throw new Error("Request cancelled");
      }
      throw new Error(
        axiosError.response?.data?.message ||
          axiosError.message ||
          "GitHub scan failed",
      );
    }
  },

  async checkHealth(): Promise<boolean> {
    try {
      const response = await axios.get(API_ENDPOINTS.scanner_health);
      return response.status === 200;
    } catch {
      return false;
    }
  },
};

export default ScannerService;
