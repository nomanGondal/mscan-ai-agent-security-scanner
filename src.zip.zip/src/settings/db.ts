import mongoose from "mongoose"

interface ConnectionObject {
  isConnected?: number
}

const connection: ConnectionObject = {}

const connect_db = async (): Promise<typeof mongoose> => {
  if (connection.isConnected) {
    return mongoose
  }

  const uri = process.env.MONGODB_URI ?? process.env.MONGO_URI

  if (!uri) {
    throw new Error("MONGODB_URI is not defined in environment variables")
  }

  try {
    const db = await mongoose.connect(uri)
    connection.isConnected = db.connections[0].readyState
    return db
  } catch (error: unknown) {
    throw error
  }
}

export { connect_db }
