"use client"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormLabel } from "@/components/ui/form"
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from "@/components/ui/input-otp"
import { Label } from "@/components/ui/label"
import { AUTH } from "@/constants"
import { verifyCodeSchema } from "@/schemas"
import { AuthStatus } from "@/types"
import { showToast, useNavigation } from "@/utiils"
import { Box } from "@radix-ui/themes"
import { Loader2 } from "lucide-react"
import { useEffect } from "react"
import { UseFormReturn } from "react-hook-form"
import * as z from "zod"

interface VERIFICATIONVIEWPROPS {
  form: UseFormReturn<z.infer<typeof verifyCodeSchema>>
  verificationProcessResponse: AuthStatus
  isVerifyingCode: boolean
  verificationCode: (
    data: z.infer<typeof verifyCodeSchema>
  ) => Promise<any> | void
}

const VerificationView = ({
  form,
  verificationProcessResponse,
  isVerifyingCode,
  verificationCode,
}: VERIFICATIONVIEWPROPS) => {
  const otpLength = 7
  const separatorIndex = 3
  const { navigateTo } = useNavigation()
  const onSubmit = async (data: z.infer<typeof verifyCodeSchema>) => {
    try {
      await verificationCode(data)
    } catch (error) {
      showToast("Verification Failed.", "error")
    }
  }

  useEffect(() => {
    if (verificationProcessResponse.success) {
      const successMessage = verificationProcessResponse.success
      showToast(successMessage, "success")
      setTimeout(() => {
        navigateTo(AUTH)
      }, 1000)
    }
    if (verificationProcessResponse.error) {
      const errorMessage = verificationProcessResponse.error
      showToast(errorMessage, "error")
    }
  })
  return (
    <Box className="w-full max-w-md mx-auto p-6 border rounded-lg flex flex-col gap-6 items-center">
      <Label className="text-2xl font-semibold text-center">
        Please enter verification code
      </Label>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <FormField
            name="verificationCode"
            control={form.control}
            render={({ field }) => {
              return (
                <FormControl>
                  <InputOTP
                    maxLength={otpLength}
                    value={field.value}
                    onChange={field.onChange}
                  >
                    <InputOTPGroup className="flex gap-2 justify-center">
                      {Array.from({ length: otpLength }).map((_, i) =>
                        i === separatorIndex ? (
                          <InputOTPSeparator key={`sep-${i}`} />
                        ) : (
                          <InputOTPSlot
                            key={i}
                            index={i}
                            className="border border-black"
                          />
                        )
                      )}
                    </InputOTPGroup>
                  </InputOTP>
                </FormControl>
              )
            }}
          />
          <Button
            type="submit"
            disabled={isVerifyingCode}
            className="cursor-pointer w-full rounded-full bg-black hover:bg-black mt-5 shadow-md"
          >
            {isVerifyingCode ? (
              <Loader2 className="animate-spin" />
            ) : (
              <Label className="cursor-pointer">Verify</Label>
            )}
          </Button>
        </form>
      </Form>
    </Box>
  )
}

export { VerificationView }
