"use client"

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { USER_DASHBOARD } from "@/constants"
import { signInSchema } from "@/schemas"
import { AuthStatus } from "@/types"
import { showToast, useNavigation } from "@/utiils"
import { Loader2 } from "lucide-react"
import { useEffect } from "react"
import { UseFormReturn } from "react-hook-form"
import z from "zod"

interface AuthFormProps {
  form: UseFormReturn<z.infer<typeof signInSchema>>
  isSigningIn: boolean
  signingUserResponse: AuthStatus
  signningInUser: (data: z.infer<typeof signInSchema>) => Promise<any> | void
}

const AuthForm = ({
  form,
  isSigningIn,
  signingUserResponse,
  signningInUser,
}: AuthFormProps) => {
  const onSubmit = async (data: z.infer<typeof signInSchema>) => {
    try {
      await signningInUser(data)
    } catch (error) {
      showToast("Auth Failed", "error")
    }
  }
  useEffect(() => {
    if (signingUserResponse.success) {
      const successMessage = signingUserResponse.success
      showToast(successMessage, "success")
    }
    if (signingUserResponse.error) {
      const errorMessage = signingUserResponse.error
      showToast(errorMessage, "error")
    }
  }, [signingUserResponse])
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <FormField
          name="identifier"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem>
                <FormLabel>Email/Username</FormLabel>
                <FormControl>
                  <Input placeholder="Email or username...." {...field} />
                </FormControl>
              </FormItem>
            )
          }}
        />
        <FormField
          name="password"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem className="mt-4">
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input placeholder="password..." {...field} />
                </FormControl>
              </FormItem>
            )
          }}
        />
        <Button
          type="submit"
          disabled={isSigningIn}
          className="cursor-pointer mt-5 rounded-full w-full bg-black hover:bg-black"
        >
          {isSigningIn ? (
            <Loader2 className="animate-spin" />
          ) : (
            <Label className="cursor-pointer">Signin</Label>
          )}
        </Button>
      </form>
    </Form>
  )
}

export { AuthForm }
