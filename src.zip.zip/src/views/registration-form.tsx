"use client"

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

import { USER_PERSONA, VERIFY_CODE } from "@/constants"
import { registrationSchema } from "@/schemas"
import { AuthStatus } from "@/types"
import { showToast } from "@/utiils"
import { useNavigation } from "@/utiils/navigation"
import { Box } from "@radix-ui/themes"
import { Loader2 } from "lucide-react"
import { useEffect } from "react"
import { UseFormReturn } from "react-hook-form"
import * as z from "zod"

interface RegistrationFormProps {
  form: UseFormReturn<z.infer<typeof registrationSchema>>
  usernameForUserRegistration: string
  debouncingForUsername: (username: string) => void
  isRegistrationUnderProgress: boolean
  registrationProcessResponse: AuthStatus
  registerUser: (
    data: z.infer<typeof registrationSchema>
  ) => Promise<any> | void
  usernameUniquenessCheckingResponse: AuthStatus
  isCheckingUsernameUniquness: boolean
}

const RegistrationForm = ({
  form,
  usernameForUserRegistration,
  debouncingForUsername,
  isRegistrationUnderProgress,
  registrationProcessResponse,
  registerUser,
  usernameUniquenessCheckingResponse,
  isCheckingUsernameUniquness,
}: RegistrationFormProps) => {
  const successMessage = usernameUniquenessCheckingResponse.success
  const errorMessage = usernameUniquenessCheckingResponse.error
  const usernameValue = form.watch("username")
  const { navigateTo } = useNavigation()

  useEffect(() => {
    if (registrationProcessResponse.success) {
      showToast(registrationProcessResponse.success, "success")
      setTimeout(() => {
        navigateTo(`${VERIFY_CODE}?username=${usernameForUserRegistration}`)
      }, 1000)
    }
    if (registrationProcessResponse.error) {
      showToast(registrationProcessResponse.error, "error")
    }
  }, [registrationProcessResponse, navigateTo, usernameForUserRegistration])

  console.log("The rrrrr", isRegistrationUnderProgress)

  const onSubmit = async (data: z.infer<typeof registrationSchema>) => {
    try {
      await registerUser(data)
    } catch (error) {
      showToast("Registration failed", "error")
    }
  }

  const personaToLower = (persona: string) =>
    persona
      .toLowerCase()
      .replaceAll("_", " ")
      .replace(/\b\w/g, (char) => char.toUpperCase())

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <FormField
          name="username"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input
                    className="border focus-visible:ring-0 focus-visible:ring-offset-0 focus:outline-none"
                    placeholder="your username..."
                    {...field}
                    onChange={(e) => {
                      field.onChange(e)
                      debouncingForUsername(e.target.value)
                    }}
                  />
                </FormControl>
                <Box className="mb-2 flex gap-2">
                  {field.value?.length > 0 && isCheckingUsernameUniquness && (
                    <Box className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <Label className="text-sm">checking username...</Label>
                    </Box>
                  )}
                  {field.value?.length > 0 &&
                    !isCheckingUsernameUniquness &&
                    usernameUniquenessCheckingResponse.success && (
                      <Label className="text-green-800 text-sm">
                        {usernameUniquenessCheckingResponse.success}
                      </Label>
                    )}
                  {field.value?.length > 0 &&
                    !isCheckingUsernameUniquness &&
                    usernameUniquenessCheckingResponse.error && (
                      <Label className="text-red-700 text-sm">
                        {usernameUniquenessCheckingResponse.error}
                      </Label>
                    )}
                </Box>
              </FormItem>
            )
          }}
        />
        <FormField
          name="email"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input
                    className="border  focus-visible:ring-0 focus-visible:ring-offset-0 focus:outline-none"
                    placeholder="your email..."
                    {...field}
                  />
                </FormControl>
              </FormItem>
            )
          }}
        />
        <FormField
          name="password"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem className="mt-3">
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Password here..."
                    {...field}
                    className="border  focus-visible:ring-0 focus-visible:ring-offset-0 focus:outline-none"
                  />
                </FormControl>
              </FormItem>
            )
          }}
        />
        <FormField
          name="fullName"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem className="mt-4">
                <FormLabel>FullName</FormLabel>
                <FormControl>
                  <Input
                    placeholder="FullName here..."
                    {...field}
                    className="border  focus-visible:ring-0 focus-visible:ring-offset-0 focus:outline-none"
                  />
                </FormControl>
              </FormItem>
            )
          }}
        />
        <FormField
          name="persona"
          control={form.control}
          render={({ field }) => {
            return (
              <FormItem className="mt-4">
                <FormLabel>Persona</FormLabel>
                <FormControl>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="border focus-visible:ring-0 focus-visible:ring-offset-0 w-full">
                      <SelectValue placeholder="Please select who describes you best..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.values(USER_PERSONA).map((persona) => (
                        <SelectItem key={persona} value={persona}>
                          {personaToLower(persona)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )
          }}
        />
        <Button
          type="submit"
          disabled={isRegistrationUnderProgress}
          className="w-full mt-4 rounded-full bg-black cursor-pointer hover:bg-black"
        >
          {isRegistrationUnderProgress ? (
            <Loader2 className="animate-spin" />
          ) : (
            "Signup"
          )}
        </Button>
      </form>
    </Form>
  )
}

export { RegistrationForm }
