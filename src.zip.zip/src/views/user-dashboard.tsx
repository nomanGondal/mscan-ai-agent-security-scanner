"use client"

import { DashboardHeader } from "@/components"
import SectionOne from "@/ui/user-dashboard/components/section-one"
import { Box } from "@radix-ui/themes"
import React from "react"

const UserDashboardView = () => {
  return (
    <Box>
      <DashboardHeader type="user" />
      <SectionOne />
    </Box>
  )
}

export { UserDashboardView }
