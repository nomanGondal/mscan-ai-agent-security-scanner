import NextTopLoader from "nextjs-toploader"
import React, { PropsWithChildren } from "react"

const ProviderLayout = ({ children }: PropsWithChildren) => {
  return (
    <>
      <NextTopLoader color="#0f0e0eff" showSpinner={false} height={3} />
      {children}
    </>
  )
}

export default ProviderLayout
