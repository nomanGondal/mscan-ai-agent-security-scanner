"use client"

import { Box } from "@radix-ui/themes"
import React from "react"
import { VerificationCodeBar } from "./components/verification-bar"
import { cn, QueryParams } from "@/utiils"
import { VerificationView } from "@/views"
import { useForm } from "react-hook-form"
import { verificationCodeSchema, verifyCodeSchema } from "@/schemas"
import * as z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useVerificationCode } from "@/hooks"
import { QUERY_PARAMS } from "@/constants"
const VerificationCode = ({ height = "h-screen", width = "w-[100vw]" }) => {
  const form = useForm<z.infer<typeof verifyCodeSchema>>({
    resolver: zodResolver(verifyCodeSchema),
    defaultValues: {
      verificationCode: "",
    },
  })

  const username = QueryParams({
    key: QUERY_PARAMS.USERNAME,
    defaultValue: QUERY_PARAMS.GUEST,
  })

  const { verificationProcessResponse, isVerifyingCode, verificationCode } =
    useVerificationCode()

  return (
    <Box
      className={cn(height, width, "flex justify-center items-center flex ")}
    >
      <VerificationCodeBar />
      <VerificationView
        form={form}
        verificationProcessResponse={verificationProcessResponse}
        isVerifyingCode={isVerifyingCode}
        verificationCode={(data) =>
          verificationCode({
            verificationCode: data.verificationCode,
            username,
          })
        }
      />
    </Box>
  )
}

export { VerificationCode }
