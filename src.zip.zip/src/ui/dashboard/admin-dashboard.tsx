"use client"

import { DashboardHeader } from "@/components"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Box, Grid, Text } from "@radix-ui/themes"
import { Users, Shield, Activity } from "lucide-react"
import { motion } from "framer-motion"

const stats = [
  {
    title: "Total Users",
    value: "1,240",
    subtitle: "Registered users",
    icon: Users,
  },
  {
    title: "Admins",
    value: "4",
    subtitle: "System administrators",
    icon: Shield,
  },
  {
    title: "System Status",
    value: "Active",
    subtitle: "All services running",
    icon: Activity,
  },
]

const AdminDashboard = () => {
  return (
    <Box className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      <DashboardHeader type="admin" />
      <Box className="px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
          className="mb-12"
        >
          <Box asChild>
            <h1 className="text-5xl md:text-6xl font-semibold tracking-tight">
              Admin Dashboard
            </h1>
          </Box>
          <Text className="mt-5 text-gray-500 text-base max-w-xl ml-3">
            Monitor users, admins, and overall system health in one place.
          </Text>
        </motion.div>
        <Grid columns={{ initial: "1", sm: "2", md: "3" }} gap="6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08, duration: 0.4 }}
            >
              <Card className="rounded-2xl border border-gray-200 bg-white shadow-sm transition-colors mt-2">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">
                    {stat.title}
                  </CardTitle>
                  <stat.icon className="h-6 w-6 text-gray-400" />
                </CardHeader>
                <CardContent>
                  <Text className="text-4xl font-semibold text-gray-900">
                    {stat.value}
                  </Text>
                  <Text size="2" className="text-gray-400 mt-1">
                    {stat.subtitle}
                  </Text>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </Grid>
      </Box>
    </Box>
  )
}

export { AdminDashboard }
