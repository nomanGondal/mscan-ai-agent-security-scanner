"use client"

import { DashboardHeader } from "@/components"
import { Box } from "@radix-ui/themes"
import UserBoard from "./components/user-board"

const UserProfile = () => {
  return (
    <Box className="h-full w-full flex flex-col">
      <DashboardHeader type="user" />
      <Box className="flex-1">
        <UserBoard />
      </Box>
    </Box>
  )
}

export { UserProfile }
