"use client"

import { Box } from "@radix-ui/themes"
import React, { useState, useEffect } from "react"
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

type ChartDataItem = {
  month: string
  scans: number
  issues: number
}

type SeverityDataItem = {
  name: string
  value: number
}

type RecentScanItem = {
  fileName: string
  issuesFound: number
  critical: number
  date: string | Date
  status?: string
}

const SectionOne = () => {
  const [metrics, setMetrics] = useState({
    totalScans: 0,
    avgIssuesPerScan: 0,
    criticalIssues: 0,
    scansRemaining: 0,
    planName: "free",
    reportsUsed: 0,
    reportsLimit: 3,
  })
  const [chartData, setChartData] = useState<ChartDataItem[]>([])
  const [severityData, setSeverityData] = useState<SeverityDataItem[]>([])
  const [recentScans, setRecentScans] = useState<RecentScanItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const response = await fetch("/api/dashboard")
      const result = await response.json()

      if (result.success) {
        const { metrics: metricsData, chartsData, recentScans: scansData } = result.data

        setMetrics(metricsData)
        setChartData(chartsData.monthlyTrend)
        setSeverityData(chartsData.severityDistribution)
        setRecentScans(scansData)
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const scanLimitPercentage =
    metrics.reportsLimit > 0
      ? (metrics.scansRemaining / metrics.reportsLimit) * 100
      : 0

  const formatScanStatus = (status?: string) => {
    if (!status) {
      return "Unknown"
    }

    return status.charAt(0).toUpperCase() + status.slice(1)
  }

  return (
    <Box className="w-full px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-black mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's your security scanning analytics.</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        {/* Total Scans */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <p className="text-gray-600 text-sm font-medium mb-2">Total Scans</p>
          <p className="text-3xl font-bold text-black">{metrics.totalScans}</p>
          <p className="text-xs text-gray-500 mt-2">All time</p>
        </div>

        {/* Average Issues */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <p className="text-gray-600 text-sm font-medium mb-2">Avg Issues/Scan</p>
          <p className="text-3xl font-bold text-black">{metrics.avgIssuesPerScan}</p>
          <p className="text-xs text-gray-500 mt-2">Per scan average</p>
        </div>

        {/* Critical Issues */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <p className="text-gray-600 text-sm font-medium mb-2">Critical Issues</p>
          <p className="text-3xl font-bold text-black">{metrics.criticalIssues}</p>
          <p className="text-xs text-gray-500 mt-2">Unresolved</p>
        </div>

        {/* Scan Limit */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <p className="text-gray-600 text-sm font-medium mb-2">Scans Remaining</p>
          <p className="text-3xl font-bold text-black">{metrics.scansRemaining}/{metrics.reportsLimit}</p>
          <div className="w-full bg-gray-200 rounded h-2 mt-3">
            <div 
              className="bg-black h-2 rounded" 
              style={{ width: `${scanLimitPercentage}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 mt-2">{metrics.planName} plan</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-2 gap-8">
        {/* Scans & Issues Over Time */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <h2 className="text-xl font-bold text-black mb-4">Scans & Issues Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #d1d5db" }} />
              <Legend />
              <Line type="monotone" dataKey="scans" stroke="#000000" strokeWidth={2} dot={{ fill: "#000000" }} />
              <Line type="monotone" dataKey="issues" stroke="#666666" strokeWidth={2} dot={{ fill: "#666666" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Issues by Severity */}
        <div className="bg-white border border-gray-300 rounded-lg p-6">
          <h2 className="text-xl font-bold text-black mb-4">Issues by Severity</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={severityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #d1d5db" }} />
              <Bar dataKey="value" fill="#000000" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Scans */}
      <div className="bg-white border border-gray-300 rounded-lg p-6 mt-8">
        <h2 className="text-xl font-bold text-black mb-4">Recent Scans</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="text-left py-3 px-4 text-sm font-bold text-gray-700">File</th>
                <th className="text-left py-3 px-4 text-sm font-bold text-gray-700">Issues Found</th>
                <th className="text-left py-3 px-4 text-sm font-bold text-gray-700">Critical</th>
                <th className="text-left py-3 px-4 text-sm font-bold text-gray-700">Date</th>
                <th className="text-left py-3 px-4 text-sm font-bold text-gray-700">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentScans.length > 0 ? (
                recentScans.map((scan, idx) => (
                  <tr key={idx} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 text-sm text-gray-900">{scan.fileName}</td>
                    <td className="py-3 px-4 text-sm text-gray-900">{scan.issuesFound}</td>
                    <td className="py-3 px-4 text-sm text-gray-900">{scan.critical}</td>
                    <td className="py-3 px-4 text-sm text-gray-600">
                      {new Date(scan.date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 text-xs font-semibold rounded ${
                        scan.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}>
                        {formatScanStatus(scan.status)}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-8 px-4 text-center text-gray-500">
                    No scans yet. Start by uploading your first file!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Box>
  )
}

export default SectionOne
