"use client";

import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  Shield,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock3,
  Loader2,
  SearchCheck,
  Files,
  Sparkles,
  Database,
  Code2,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/utiils";
import ScannerService, { ScanResult } from "@/services/scanner";
import { DemoTestSection } from "./components/demo-test-section";
import { VulnerabilityCard } from "./components/vulnerability-card";
import { toast } from "react-toastify";

const severityOrder: Array<"critical" | "high" | "medium" | "low"> = [
  "critical",
  "high",
  "medium",
  "low",
];

const defaultScanState = {
  status: "idle" as "idle" | "scanning" | "completed" | "error",
  message: "Upload a zip file or run the demo test to start scanning.",
};

const formatStatus = (status?: string) => {
  if (!status) return "unknown";
  return status.replace(/_/g, " ");
};

const formatStageLabel = (stage: string) => {
  switch (stage) {
    case "mcp_ast":
      return "AST";
    case "pyre_typing":
      return "Pyre";
    case "pysa_taint":
      return "Pysa";
    default:
      return "Other";
  }
};

const stageOrder: Array<"mcp_ast" | "pyre_typing" | "pysa_taint" | "unknown"> =
  ["mcp_ast", "pyre_typing", "pysa_taint", "unknown"];

const ScannerDashboard = () => {
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanState, setScanState] = useState(defaultScanState);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [fileName, setFileName] = useState("");

  const vulnerabilities = useMemo(() => {
    if (!scanResult?.vulnerabilities?.length) return [];
    return [...scanResult.vulnerabilities].sort(
      (a, b) =>
        severityOrder.indexOf(a.severity) - severityOrder.indexOf(b.severity),
    );
  }, [scanResult]);

  const issuesByStage = useMemo(() => {
    const grouped: Record<string, typeof vulnerabilities> = {
      mcp_ast: [],
      pyre_typing: [],
      pysa_taint: [],
      unknown: [],
    };

    for (const issue of vulnerabilities) {
      const stage = issue.analysisStage ?? "unknown";
      grouped[stage]?.push(issue);
    }

    return grouped;
  }, [vulnerabilities]);

  const fileReports = useMemo(() => {
    const files = new Map<
      string,
      {
        fileName: string;
        findings: typeof vulnerabilities;
      }
    >();

    for (const issue of vulnerabilities) {
      const key = issue.file || "Unmapped findings";
      const existing = files.get(key);
      if (existing) {
        existing.findings.push(issue);
      } else {
        files.set(key, {
          fileName: key,
          findings: [issue],
        });
      }
    }

    return Array.from(files.values()).sort(
      (left, right) => right.findings.length - left.findings.length,
    );
  }, [vulnerabilities]);

  const summary = scanResult?.summary ?? {
    total_issues: 0,
    critical_count: 0,
    high_count: 0,
    medium_count: 0,
    low_count: 0,
  };

  const handleDemoResults = (result: ScanResult) => {
    setScanResult(result);
    setScanState({
      status: "completed",
      message: "Demo scan completed successfully.",
    });
  };

  const handleFileChange = (file: File | null) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".zip")) {
      toast.error("Please select a .zip file");
      return;
    }
    setSelectedFile(file);
    setFileName(file.name);
  };

  const handleScanZip = async () => {
    if (!selectedFile || isUploading) return;

    setIsUploading(true);
    setScanState({
      status: "scanning",
      message: "Uploading and analyzing your zip...",
    });

    try {
      const result = await ScannerService.scanZip(selectedFile);
      if (result) {
        setScanResult(result);
        setScanState({
          status: "completed",
          message: "Scan finished. Review the findings below.",
        });
        toast.success("ZIP scan completed");
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Scan failed";
      setScanState({ status: "error", message });
      toast.error(message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_rgba(59,130,246,0.12),_transparent_30%),radial-gradient(circle_at_top_right,_rgba(168,85,247,0.12),_transparent_35%),linear-gradient(180deg,#f8fbff_0%,#eef4ff_100%)] text-slate-900">
      <div className="relative mx-auto max-w-7xl px-4 py-6 md:px-6 md:py-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="overflow-hidden rounded-3xl border border-white/70 bg-white/75 shadow-[0_20px_80px_rgba(15,23,42,0.08)] backdrop-blur"
        >
          <div className="relative px-6 py-8 md:px-10 md:py-12">
            <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl">
              <div className="absolute left-0 top-0 h-72 w-72 rounded-full bg-blue-400/10 blur-3xl" />
              <div className="absolute right-0 top-12 h-80 w-80 rounded-full bg-purple-400/10 blur-3xl" />
              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(148,163,184,0.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.08)_1px,transparent_1px)] bg-[size:28px_28px]" />
            </div>

            <div className="relative z-10 grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700 shadow-sm">
                  <Sparkles className="h-4 w-4" />
                  Vulnerability Scanner for AI Agents
                </div>

                <div className="space-y-4">
                  <h1 className="max-w-3xl text-4xl font-black tracking-tight text-slate-950 md:text-6xl">
                    Scan code, upload zip projects, and review security findings
                    in one place.
                  </h1>
                  <p className="max-w-2xl text-base leading-7 text-slate-600 md:text-lg">
                    Run a quick demo against sample Python code, then upload
                    your zip folder for a full analysis with critical, high,
                    medium, and low findings presented cleanly.
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  {[
                    {
                      label: "Critical Issues",
                      value: summary.critical_count,
                      icon: AlertTriangle,
                    },
                    {
                      label: "Files Analyzed",
                      value: scanResult?.files_analyzed ?? 0,
                      icon: Files,
                    },
                    {
                      label: "Total Findings",
                      value: summary.total_issues,
                      icon: Activity,
                    },
                  ].map((item) => (
                    <motion.div
                      key={item.label}
                      whileHover={{ y: -2 }}
                      className="rounded-2xl border border-slate-200 bg-white/90 p-4 shadow-sm"
                    >
                      <div className="flex items-center justify-between text-sm text-slate-500">
                        <span>{item.label}</span>
                        <item.icon className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="mt-3 text-3xl font-black text-slate-950">
                        {item.value}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="rounded-3xl border border-slate-200 bg-slate-950 p-5 text-white shadow-2xl"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">Scanner status</p>
                    <h2 className="text-xl font-semibold text-white">
                      {formatStatus(scanState.status)}
                    </h2>
                  </div>
                  <div className="rounded-2xl bg-white/10 p-3">
                    {scanState.status === "scanning" ? (
                      <Loader2 className="h-6 w-6 animate-spin text-cyan-300" />
                    ) : scanState.status === "completed" ? (
                      <CheckCircle2 className="h-6 w-6 text-emerald-300" />
                    ) : scanState.status === "error" ? (
                      <AlertTriangle className="h-6 w-6 text-red-300" />
                    ) : (
                      <Shield className="h-6 w-6 text-blue-300" />
                    )}
                  </div>
                </div>

                <p className="mt-4 text-sm leading-6 text-slate-300">
                  {scanState.message}
                </p>

                <div className="mt-6 grid grid-cols-2 gap-3">
                  {[
                    {
                      label: "Critical",
                      value: summary.critical_count,
                      tone: "text-red-300",
                    },
                    {
                      label: "High",
                      value: summary.high_count,
                      tone: "text-orange-300",
                    },
                    {
                      label: "Medium",
                      value: summary.medium_count,
                      tone: "text-yellow-300",
                    },
                    {
                      label: "Low",
                      value: summary.low_count,
                      tone: "text-sky-300",
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded-2xl border border-white/10 bg-white/5 p-4"
                    >
                      <div className="text-xs uppercase tracking-[0.2em] text-slate-400">
                        {item.label}
                      </div>
                      <div className={cn("mt-2 text-2xl font-bold", item.tone)}>
                        {item.value}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <DemoTestSection onResultsReady={handleDemoResults} />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="relative overflow-hidden border border-slate-200 bg-white shadow-lg">
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(59,130,246,0.05),transparent_40%),linear-gradient(225deg,rgba(168,85,247,0.05),transparent_45%)]" />
              <div className="relative p-6 md:p-8">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-slate-600">
                      <Database className="h-3.5 w-3.5" />
                      Zip Upload Scan
                    </div>
                    <h3 className="mt-4 text-2xl font-bold text-slate-950">
                      Upload a project zip and get a full report.
                    </h3>
                    <p className="mt-2 max-w-xl text-sm leading-6 text-slate-600">
                      The scanner will analyze the archive, return the severity
                      summary, and list the affected files with recommendations.
                    </p>
                  </div>
                  <div className="rounded-2xl bg-slate-950 p-3 text-white">
                    <Code2 className="h-5 w-5" />
                  </div>
                </div>

                <div
                  className={cn(
                    "group mt-6 rounded-3xl border-2 border-dashed p-6 text-center transition-all duration-300",
                    dragActive
                      ? "border-blue-500 bg-blue-50"
                      : "border-slate-300 bg-slate-50 hover:border-blue-400 hover:bg-blue-50/60",
                  )}
                  onDragOver={(event) => {
                    event.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={(event) => {
                    event.preventDefault();
                    setDragActive(false);
                    handleFileChange(event.dataTransfer.files?.[0] ?? null);
                  }}
                >
                  <input
                    type="file"
                    accept=".zip"
                    className="hidden"
                    id="zip-upload"
                    onChange={(event) =>
                      handleFileChange(event.target.files?.[0] ?? null)
                    }
                  />
                  <label htmlFor="zip-upload" className="cursor-pointer">
                    <motion.div
                      animate={{ y: [0, -4, 0] }}
                      transition={{ duration: 2.5, repeat: Infinity }}
                      className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-white shadow-sm"
                    >
                      <Upload className="h-7 w-7 text-blue-600" />
                    </motion.div>
                    <div className="mt-4 space-y-2">
                      <p className="text-base font-semibold text-slate-900">
                        Drop your zip here or click to browse
                      </p>
                      <p className="text-sm text-slate-500">
                        Only .zip files are supported, up to 25 MB.
                      </p>
                    </div>
                  </label>
                </div>

                {selectedFile && (
                  <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                          Selected file
                        </p>
                        <p className="mt-1 font-medium text-slate-900">
                          {fileName}
                        </p>
                      </div>
                      <Button
                        onClick={handleScanZip}
                        disabled={isUploading}
                        className="inline-flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-2.5 text-white hover:bg-slate-800"
                      >
                        {isUploading ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <SearchCheck className="h-4 w-4" />
                        )}
                        {isUploading ? "Scanning..." : "Run Full Scan"}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-8"
        >
          <Card className="overflow-hidden border border-slate-200 bg-white shadow-lg">
            <div className="border-b border-slate-200 px-6 py-4 md:px-8">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-950">Results</h3>
                  <p className="text-sm text-slate-500">
                    Critical findings are surfaced first, with clear file and
                    line references.
                  </p>
                </div>
                <Badge className="w-fit rounded-full bg-slate-900 px-4 py-1.5 text-white hover:bg-slate-900">
                  {scanResult
                    ? `${summary.total_issues} findings`
                    : "Awaiting scan"}
                </Badge>
              </div>
            </div>

            <div className="p-6 md:p-8">
              {scanResult ? (
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-4">
                    {[
                      {
                        label: "Status",
                        value: scanResult.status,
                        icon: Clock3,
                      },
                      {
                        label: "Project",
                        value: scanResult.project_id,
                        icon: Shield,
                      },
                      {
                        label: "Scan Time",
                        value: `${scanResult.scan_time ?? "-"}s`,
                        icon: Activity,
                      },
                      {
                        label: "Files",
                        value: scanResult.files_analyzed,
                        icon: Files,
                      },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                      >
                        <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-500">
                          <span>{item.label}</span>
                          <item.icon className="h-4 w-4" />
                        </div>
                        <div className="mt-3 break-all text-sm font-semibold text-slate-950">
                          {item.value}
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    {[
                      {
                        label: "Critical",
                        value: summary.critical_count,
                        tone: "from-red-500 to-red-600",
                      },
                      {
                        label: "High",
                        value: summary.high_count,
                        tone: "from-orange-500 to-orange-600",
                      },
                      {
                        label: "Medium",
                        value: summary.medium_count,
                        tone: "from-yellow-500 to-yellow-600",
                      },
                      {
                        label: "Low",
                        value: summary.low_count,
                        tone: "from-blue-500 to-blue-600",
                      },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className={cn(
                          "rounded-2xl bg-gradient-to-br p-[1px]",
                          item.tone,
                        )}
                      >
                        <div className="rounded-2xl bg-white p-4">
                          <div className="text-sm text-slate-500">
                            {item.label}
                          </div>
                          <div className="mt-2 text-3xl font-black text-slate-950">
                            {item.value}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="grid gap-4 lg:grid-cols-3">
                    {[
                      {
                        key: "mcp_ast",
                        label: "AST Findings",
                        value: scanResult.analysisBreakdown?.ast ?? 0,
                        description: "Structure, sinks, and insecure patterns.",
                      },
                      {
                        key: "pyre_typing",
                        label: "Pyre Findings",
                        value: scanResult.analysisBreakdown?.pyre ?? 0,
                        description: "Type-checking and annotation issues.",
                      },
                      {
                        key: "pysa_taint",
                        label: "Pysa Findings",
                        value: scanResult.analysisBreakdown?.pysa ?? 0,
                        description: "Data-flow and taint propagation issues.",
                      },
                    ].map((item) => (
                      <div
                        key={item.key}
                        className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <div className="text-sm font-semibold text-slate-900">
                              {item.label}
                            </div>
                            <p className="mt-1 text-xs leading-5 text-slate-500">
                              {item.description}
                            </p>
                          </div>
                          <div className="rounded-2xl bg-slate-950 px-3 py-2 text-lg font-black text-white">
                            {item.value}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-end justify-between gap-3">
                      <div>
                        <h4 className="text-lg font-semibold text-slate-950">
                          Findings by Stage
                        </h4>
                        <p className="text-sm text-slate-500">
                          Each section mirrors the scanner pipeline: AST, Pyre,
                          and Pysa.
                        </p>
                      </div>
                      <Badge className="rounded-full bg-slate-100 px-3 py-1.5 text-slate-700 hover:bg-slate-100">
                        {vulnerabilities.length} issues
                      </Badge>
                    </div>

                    {vulnerabilities.length > 0 ? (
                      <div className="space-y-5">
                        {stageOrder.map((stage) => {
                          const stageIssues = issuesByStage[stage] ?? [];

                          return (
                            <section
                              key={stage}
                              className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                            >
                              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                  <h5 className="text-base font-semibold text-slate-950">
                                    {formatStageLabel(stage)} Report
                                  </h5>
                                  <p className="text-xs text-slate-500">
                                    {stage === "mcp_ast"
                                      ? "Structural and source-pattern findings."
                                      : stage === "pyre_typing"
                                        ? "Static type and annotation findings."
                                        : stage === "pysa_taint"
                                          ? "Taint-flow and propagation findings."
                                          : "Unclassified findings."}
                                  </p>
                                </div>
                                <div className="rounded-full bg-white px-3 py-1 text-sm font-semibold text-slate-700 shadow-sm">
                                  {stageIssues.length} issues
                                </div>
                              </div>

                              {stageIssues.length > 0 ? (
                                <div className="mt-4 space-y-3">
                                  <AnimatePresence initial={false}>
                                    {stageIssues.map((vuln, index) => (
                                      <motion.div
                                        key={`${stage}-${vuln.file}-${vuln.line}-${index}`}
                                        initial={{ opacity: 0, y: 12 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -12 }}
                                        transition={{
                                          duration: 0.25,
                                          delay: index * 0.03,
                                        }}
                                      >
                                        <VulnerabilityCard
                                          severity={vuln.severity}
                                          title={vuln.title}
                                          description={vuln.description}
                                          file={vuln.file}
                                          line={vuln.line}
                                          column={vuln.column}
                                          codeSnippet={vuln.code_snippet}
                                          recommendation={vuln.recommendation}
                                          cwe={vuln.cwe}
                                          owasp={vuln.owasp}
                                        />
                                      </motion.div>
                                    ))}
                                  </AnimatePresence>
                                </div>
                              ) : (
                                <div className="mt-4 rounded-xl border border-dashed border-slate-300 bg-white p-4 text-sm text-slate-500">
                                  No findings were attributed to this stage in
                                  the current scan.
                                </div>
                              )}
                            </section>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
                        <p className="text-sm font-medium text-slate-900">
                          No findings to show yet.
                        </p>
                        <p className="mt-2 text-sm text-slate-500">
                          Run the demo or upload a zip to populate this section.
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-lg font-semibold text-slate-950">
                        File Reports
                      </h4>
                      <p className="text-sm text-slate-500">
                        Findings grouped by file so you can inspect the affected
                        paths quickly.
                      </p>
                    </div>

                    {fileReports.length > 0 ? (
                      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                        {fileReports.map((report) => {
                          const criticalCount = report.findings.filter(
                            (issue) => issue.severity === "critical",
                          ).length;
                          const highCount = report.findings.filter(
                            (issue) => issue.severity === "high",
                          ).length;

                          return (
                            <div
                              key={report.fileName}
                              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0">
                                  <p className="truncate text-sm font-semibold text-slate-950">
                                    {report.fileName}
                                  </p>
                                  <p className="mt-1 text-xs text-slate-500">
                                    {report.findings.length} findings
                                  </p>
                                </div>
                                <div className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                                  {criticalCount}C / {highCount}H
                                </div>
                              </div>

                              <div className="mt-4 space-y-2">
                                {report.findings
                                  .slice(0, 3)
                                  .map((issue, index) => (
                                    <div
                                      key={`${report.fileName}-${index}`}
                                      className="rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-600"
                                    >
                                      <span className="font-semibold text-slate-900">
                                        {issue.title}
                                      </span>
                                      <span className="ml-2">
                                        {formatStageLabel(
                                          issue.analysisStage ?? "unknown",
                                        )}
                                      </span>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-sm text-slate-500">
                        File-level reports will appear after a scan finishes.
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
                  <p className="text-base font-semibold text-slate-900">
                    Results will appear here
                  </p>
                  <p className="mt-2 text-sm text-slate-500">
                    Demo scans and uploaded zip scans will render a structured
                    summary here.
                  </p>
                </div>
              )}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export { ScannerDashboard };
