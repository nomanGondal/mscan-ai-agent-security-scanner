"use client";

import React from "react";
import { motion } from "framer-motion";
import { Upload, Play, Loader2, FileArchive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "react-toastify";
import ScannerService, { ScanResult } from "@/services/scanner";
import { cn } from "@/utiils";

interface DemoTestSectionProps {
  onResultsReady: (results: ScanResult) => void;
}

export const DemoTestSection: React.FC<DemoTestSectionProps> = ({
  onResultsReady,
}) => {
  const [isScanning, setIsScanning] = React.useState(false);
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
  const [fileName, setFileName] = React.useState("");

  const handleFileSelect = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith(".zip")) {
      toast.error("Please select a .zip file");
      event.target.value = "";
      return;
    }

    setSelectedFile(file);
    setFileName(file.name);
  };

  const handleRunDemo = async () => {
    if (!selectedFile || isScanning) return;

    setIsScanning(true);
    try {
      const result = await ScannerService.scanZip(selectedFile);

      if (result) {
        onResultsReady(result);
        toast.success("ZIP scan completed!");
      }
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "ZIP scan failed";
      toast.error(message);
      console.error("ZIP scan error:", error);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden border-2 border-purple-200 bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div className="p-6 md:p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900">
                ZIP Scan
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Upload a project archive and run the real scan_zip endpoint
              </p>
            </div>
            <motion.div
              className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center"
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity }}
            >
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                <FileArchive className="w-5 h-5 text-purple-600" />
              </div>
            </motion.div>
          </div>

          <div className="rounded-2xl border border-dashed border-purple-200 bg-white/70 p-4 md:p-5">
            <label className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-8 text-center transition hover:border-slate-300 hover:bg-slate-100">
              <Upload className="h-8 w-8 text-slate-500" />
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  Drop your ZIP here or click to choose a file
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  The scanner will send this archive to the configured scan_zip endpoint.
                </p>
              </div>
              <input
                type="file"
                accept=".zip"
                className="hidden"
                onChange={handleFileSelect}
              />
            </label>

            {fileName ? (
              <div className="mt-4 flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{fileName}</p>
                  <p className="text-xs text-slate-500">Ready to scan</p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedFile(null);
                    setFileName("");
                  }}
                >
                  Clear
                </Button>
              </div>
            ) : null}

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleRunDemo}
              disabled={!selectedFile || isScanning}
              className={cn(
                "mt-4 flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all md:text-base",
                isScanning || !selectedFile
                  ? "bg-gradient-to-r from-purple-400 to-blue-400 text-white opacity-75"
                  : "bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 shadow-lg hover:shadow-xl",
              )}
            >
              {isScanning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run ZIP Scan
                </>
              )}
            </motion.button>
          </div>

          {/* Info Box */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg"
          >
            <p className="text-xs md:text-sm text-blue-800">
              <span className="font-semibold">💡 Tip:</span> This section now
              uses the real ZIP scanning endpoint, so the results match what the
              backend returns for uploaded projects.
            </p>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
};
