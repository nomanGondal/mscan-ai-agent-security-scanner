"use client"

import React from "react"
import { Box } from "@radix-ui/themes"
import { cn } from "@/utiils"
import { Header } from "@/components"
import { SectionOne } from "./components"
import { Montserrat } from "next/font/google"
import ButtonSection from "./components/buttons-section"
interface LandingProps {
  height?: string
  width?: string
}

const montText = Montserrat({
  subsets: ["latin"],
})

const Landing = ({ height = "h-screen", width = "w-full" }: LandingProps) => {
  return (
    <Box
      className={cn(height, width, "relative overflow-hidden bg-white pt-2")}
    >
      <div className="absolute inset-0 z-0 pointer-events-none mt-18">
        <div className="absolute inset-0 h-full w-full bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]" />
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 mt-10 h-[310px] w-[310px] rounded-full bg-fuchsia-400 opacity-20 blur-[100px]" />
      </div>
      <Header />
      <SectionOne font={montText.className} />
      <ButtonSection />
    </Box>
  )
}

export { Landing }
