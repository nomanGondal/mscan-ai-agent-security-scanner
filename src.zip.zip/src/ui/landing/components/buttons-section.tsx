"use client"

import { RightArrow } from "@/components"
import { Button } from "@/components/ui/button"
import { Box } from "@radix-ui/themes"

const ButtonSection = () => {
  return (
    <Box className="w-full mt-10 flex justify-center items-center pt-2">
      <Box className="flex gap-4">
        <Button
          variant="outline"
          className="rounded-full cursor-pointer shadow-md"
        >
          Documentation
        </Button>
        <Button className="bg-black p-4 rounded-full font-normal px-6 hover:bg-black cursor-pointer shadow-md   ">
          Get Started
          <RightArrow />
        </Button>
      </Box>
    </Box>
  )
}

export default ButtonSection
