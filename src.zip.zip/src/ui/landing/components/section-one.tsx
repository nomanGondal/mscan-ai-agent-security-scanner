"use client"

import { LandingBadge } from "@/components"
import { cn } from "@/utiils"
import { Box, Text } from "@radix-ui/themes"
import { Server, Shield, Zap } from "lucide-react"
import Link from "next/link"

interface SectionOneProps {
  font: string
}

const SectionOne = ({ font }: SectionOneProps) => {
  return (
    <Box className="w-full overflow-hidden px-20 mt-0 pt-12 flex justify-center items-center text-center flex-col relative">
      <Box className="absolute top-10 left-30 w-12 h-12 bg-purple-400/20 backdrop-blur-lg rounded-xl animate-float-slow flex items-center justify-center shadow-lg">
        <Shield className="w-6 h-6 text-purple-700" />
      </Box>
      <Box className="absolute top-20 right-20 w-12 h-12 shadow-lg bg-blue-400/20 backdrop-blur-lg rounded-xl animate-float-medium flex items-center justify-center">
        <Server className="w-6 h-6 text-blue-700" />
      </Box>
      <Box className="absolute bottom-5 left-1/6 -translate-x-1/2 w-12 h-12 bg-fuchsia-400/20 backdrop-blur-lg rounded-xl animate-float-fast flex items-center justify-center shadow-lg">
        <Zap className="w-6 h-6 text-fuchsia-700" />
      </Box>
      <LandingBadge />
      <Text
        className={cn(
          "text-6xl font-[600] leading-[1.3] text-center mt-6 relative z-10",
          font
        )}
      >
        Protect Your{" "}
        <span className="relative inline-block">
          <span className="bg-gradient-to-r from-purple-900 via-blue-700 to-blue-400 bg-clip-text text-transparent animate-gradient-x">
            MCP Agents
          </span>
          <span className="absolute left-0 bottom-0 animate-underline-gradient"></span>
        </span>{" "}
        with Automated Vulnerability Scanning Today
      </Text>
      <Text className="mt-6 text-lg font-medium text-gray-700 dark:text-gray-200 font-normal">
        Want to see how <span className="font-semibold">MVSCAN</span> works?{" "}
        <Link
          href="#how-it-works"
          className="text-blue-500 underline hover:text-blue-700 transition"
        >
          Check it out
        </Link>
      </Text>
    </Box>
  )
}

export { SectionOne }
