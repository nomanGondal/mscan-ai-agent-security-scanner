"use client"

import { cn } from "@/lib/utils"
import { Box } from "@radix-ui/themes"
import { AuthBar } from "./components/auth-bar"
import { AuthForm } from "@/views"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { useForm } from "react-hook-form"
import { signInSchema } from "@/schemas"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useAuth } from "@/hooks"

interface AuthProps {
  height: string
  width: string
}

const Auth = ({ height = "h-screen", width = "w-[100vw]" }: AuthProps) => {
  const form = useForm<z.infer<typeof signInSchema>>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  })
  const { isSigningUser, signingUserResponse, signningInUser } = useAuth()
  return (
    <Box
      className={cn(height, width, "flex justify-center items-center flex ")}
    >
      <AuthBar />
      <Box className="w-[45%] p-25">
        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
            <CardDescription>
              Please login using valid credentials.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AuthForm
              form={form}
              isSigningIn={isSigningUser}
              signingUserResponse={signingUserResponse}
              signningInUser={signningInUser}
            />
          </CardContent>
        </Card>
      </Box>
    </Box>
  )
}

export { Auth }
