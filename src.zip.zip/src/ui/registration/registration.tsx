"use client"

import React from "react"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { registrationSchema } from "@/schemas"
import { useRegistration, useUsernameUniqueness } from "@/hooks"
import { useDebounceCallback } from "usehooks-ts"
import { Box } from "@radix-ui/themes"
import { cn } from "@/lib/utils"
import { RegistrationForm } from "@/views"
import { Bar } from "./components/bar"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

interface RegistrationPageProps {
  height?: string
  width?: string
}

const Registration = ({
  height = "h-screen",
  width = "w-[100vw]",
}: RegistrationPageProps) => {
  
  const form = useForm<z.infer<typeof registrationSchema>>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      fullName: "",
      persona: "",
    },
  })

  const {
    usernameForUserRegistration,
    setUsernameForUserRegistration,
    isRegistrationUnderProgress,
    registrationProcessResponse,
    registerUser,
  } = useRegistration()

  const {
    usernameUniquenessCheckingResponse,
    checkUsername,
    isCheckingUsernameUniquness,
  } = useUsernameUniqueness()

  const debouncingForUsername = useDebounceCallback((username: string) => {
    setUsernameForUserRegistration(username)
    if (username.trim().length > 1) {
      checkUsername(username)
    }
  }, 2000)

  return (
    <Box
      className={cn(height, width, "flex justify-center items-center flex ")}
    >
      <Bar />
      <Box className="w-[45%] p-8">
        <Card className="border  shadow-none rounded-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Signup</CardTitle>
            <CardDescription>
              Please register your account with valid information.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <RegistrationForm
              form={form}
              usernameForUserRegistration={usernameForUserRegistration}
              debouncingForUsername={debouncingForUsername}
              isRegistrationUnderProgress={isRegistrationUnderProgress}
              registrationProcessResponse={registrationProcessResponse}
              registerUser={registerUser}
              usernameUniquenessCheckingResponse={
                usernameUniquenessCheckingResponse
              }
              isCheckingUsernameUniquness={isCheckingUsernameUniquness}
            />
          </CardContent>
        </Card>
      </Box>
    </Box>
  )
}

export { Registration }
