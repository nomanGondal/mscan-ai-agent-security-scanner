import {
  Head,
  Heading,
  Html,
  Preview,
  Row,
  Section,
  Text,
} from "@react-email/components"

interface VerificationTemplateProps {
  username: string
  otp: string | number
}

const VerificationTemplate = ({ username, otp }: VerificationTemplateProps) => {
  return (
    <Html>
      <Head>
        <title>Acccount Verifiaction OTP from MVSCAN.</title>
      </Head>
      <Preview>Heres your account verification code.</Preview>
      <Section>
        <Row>
          <Text>
            ********************************************************************
          </Text>
        </Row>
        <Row>
          <Heading as="h2">Hello, {username}</Heading>
        </Row>
        <Row>
          <Text>Thank you for registering yourself on MVSCAN.</Text>
        </Row>
        <Row>
          <Text>{otp}</Text>
        </Row>
        <Row>
          <Text>
            ********************************************************************
          </Text>
        </Row>
      </Section>
    </Html>
  )
}

export { VerificationTemplate }
