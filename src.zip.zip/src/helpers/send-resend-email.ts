import { VerificationTemplate } from "@/email"
import { getResendClient } from "@/service-email/resend-call"
import { ResendType } from "./types/resend-types"
interface sendVerificationCodeProps {
  email?: string
  username: string
  otp: number | string
}

const sendVerificationCode = async ({
  email,
  username,
  otp,
}: sendVerificationCodeProps): Promise<ResendType> => {
  try {
    const resend = await getResendClient()
    const { data, error } = await resend.emails.send({
      from: "Acme <onboarding@resend.dev>",
      to: "alihassan26032004@gmail.com",
      subject: "Your Verification Code",
      react: VerificationTemplate({
        username: username,
        otp: otp,
      }),
    })
    if (error) {
      return {
        success: false,
        message: error?.message || "Failed to send Verification Code.",
        statusCode: 400,
        timestamps: new Date().toISOString(),
      }
    }
    return {
      success: true,
      message: "Verification code sent successfully",
      statusCode: 200,
      timestamps: new Date().toISOString(),
      data,
    }
  } catch (error: unknown) {
    let errorName = "Error"
    let errorMessage = "Unknown Server Error"
    let errorStack: string | undefined = undefined

    if (error instanceof Error) {
      errorName = error.name
      errorMessage = error.message
      errorStack = error.stack
    }

    return {
      statusCode: 500,
      message: "Cannot send email network error",
      success: false,
      timestamps: new Date().toISOString(),
      error: {
        name: errorName,
        message: errorMessage,
        stack: errorStack,
      },
    }
  }
}

export { sendVerificationCode }
