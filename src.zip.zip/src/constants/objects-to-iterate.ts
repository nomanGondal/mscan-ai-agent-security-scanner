import {
  ADMIN_DASHBOARD,
  ADMIN_MANAGE_USERS,
  ADMIN_USER_REPORTS,
  ACCOUNT_SETTINGS,
  CHECKOUT,
  DASHBOARD,
  DOCS,
  HISTORY,
  PRICING,
  SCANNER,
  SUBSCRIPTION,
} from "./page-urls";

const USER_HEADER_LINKS = [
  { label: "Dashboard", href: DASHBOARD },
  { label: "History", href: HISTORY },
  { label: "Scanner", href: SCANNER },
  { label: "Pricing", href: PRICING },
  { label: "Settings", href: ACCOUNT_SETTINGS },
  { label: "Docs", href: DOCS },
];

const ADMIN_HEADER_LINKS = [
  { label: "Home", href: ADMIN_DASHBOARD },
  { label: "Manage Users", href: ADMIN_USER_REPORTS },
  { label: "Analytics", href: ADMIN_MANAGE_USERS },
];

const USER_DROPDOWN = [
  { label: "Settings", href: ACCOUNT_SETTINGS },
  { label: "Subscription", href: SUBSCRIPTION },
  { label: "Checkout", href: CHECKOUT },
];

const ADMIN_DROPDOWN = [
  { label: "Profile", href: "#" },
  { label: "Account", href: "#" },
  { label: "Reports", href: "#" },
  { label: "Settings", href: "#" },
];

export interface UserField {
  label: string;
  value: string | number;
}

type UserDetails = {
  email: string;
  persona: string;
  isActive: boolean;
  isUserVerified: boolean;
  createdAt: string | number | Date;
};

const GETUSERFIELDS = (user: UserDetails): UserField[] => [
  { label: "Email", value: user.email },
  { label: "Persona", value: user.persona },
  { label: "Active", value: user.isActive ? "Yes" : "No" },
  { label: "Verified", value: user.isUserVerified ? "Yes" : "No" },
  { label: "Created At", value: new Date(user.createdAt).toLocaleString() },
];

const GETUSERACCOUNTDETAILSFIELDS = (
  formatDate: (value: string | number | Date | null | undefined) => string,
  accountDetailsForUser: {
    plan: string;
    subscriptionStatus: string;
    isTrialActive: boolean;
    trialStartDate: string | number | Date | null | undefined;
    trialEndDate: string | number | Date | null | undefined;
    reportsUsed: number;
    reportsLimit: number;
    createdAt: string | number | Date | null | undefined;
  },
): UserField[] => [
  { label: "Plan", value: accountDetailsForUser.plan },
  {
    label: "Subscription Status",
    value: accountDetailsForUser.subscriptionStatus,
  },
  {
    label: "Trial Active",
    value: accountDetailsForUser.isTrialActive ? "Yes" : "No",
  },
  {
    label: "Trial Start Date",
    value: formatDate(accountDetailsForUser.trialStartDate),
  },
  {
    label: "Trial End Date",
    value: formatDate(accountDetailsForUser.trialEndDate),
  },
  {
    label: "Reports Used",
    value: `${accountDetailsForUser.reportsUsed}`,
  },
  {
    label: "Reports Limit",
    value: `${accountDetailsForUser.reportsLimit}`,
  },
  {
    label: "Account Created At",
    value: formatDate(accountDetailsForUser.createdAt),
  },
];

export {
  USER_HEADER_LINKS,
  ADMIN_HEADER_LINKS,
  USER_DROPDOWN,
  ADMIN_DROPDOWN,
  GETUSERFIELDS,
  GETUSERACCOUNTDETAILSFIELDS,
};
